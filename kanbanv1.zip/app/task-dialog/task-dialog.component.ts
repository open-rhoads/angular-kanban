//controller for the task-dialog component
//import Inject from Angular core, MAT_DIALOG_DATA/MatDialogRef from material
//import custom Task component
import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { Task } from '../task/task';

@Component({
  selector: 'app-task-dialog',
  templateUrl: './task-dialog.component.html',
  styleUrls: ['./task-dialog.component.css']
})

export class TaskDialogComponent {
  //define private backupTask of type Partial<Task> deconstructs the current initial task data into the task...
  private backupTask: Partial<Task> = { ...this.data.task };
  //constructor defines a public dialogRef of type MatDialogRef<TaskDialonComponent>
  //and injects a reference to the dialog so we can close it and inject the value of the MAT_DIALOG_DATA token
  //that is the data object passed to the open method in the AppComponent
  //defines the data variable of type TaskDialogData
  constructor(
    public dialogRef: MatDialogRef<TaskDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: TaskDialogData
  ) {}
//cancel method calls backupTask method to reset values of title and description and closes containing the previously entered data
//restores the possibly changed values
  cancel(): void {
    this.data.task.title = this.backupTask.title;
    this.data.task.description = this.backupTask.description;
    this.dialogRef.close(this.data);
  }
}

//TaskDialogData & TaskDialogResult interfaces

//task property is of type Partial<Task>
//enableDelete property is declared Boolean
export interface TaskDialogData {
  task: Partial<Task>;
  enableDelete: boolean;
}
//task property is of type Task
//delete property is declared Boolean
export interface TaskDialogResult {
  task: Task;
  delete?: boolean;
}