import { Component } from '@angular/core';
//import Task class component
import { Task } from './task/task';
//import CdkDrapDrop and transferArrayItem class/method from cdk
import { CdkDragDrop, transferArrayItem } from '@angular/cdk/drag-drop';
//import MatDialog component from material to use for adding tasks
import { MatDialog } from '@angular/material/dialog';
//import TaskDialogComponent
import { TaskDialogComponent } from './task-dialog/task-dialog.component';
//import TaskDialogResult
import { TaskDialogResult } from './task-dialog/task-dialog.component';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent {
  //app title
  title = 'kanban_board';

  //define array of todos of type Task to display in board ... this is to be updated in Firebase version
  //example: todo = this.store.collection('todo').valueChanges({ idField: 'id' }) as Observable<Task[]>;
  //observables are used...which means that the add,edit, remove & drop methods need to be edited to work with observables
  //is this where I should add local storage? or use click events on the Ok button...to call a new method that sets localStorage
  todo: Task[] = [
    {
      title: 'Create Form Handling Script',
      description: 'Write a backend form handling script to perform server-side processing for a form.'
    },
    {
      title: 'Add animations to transition pages',
      description: 'Create visual loading animations on slower pages with CSS framework of your choosing.'
    }
  ];
  //define inProgress array of Tasks, initialized empty... this is to be updated in Firebase version
  inProgress: Task [] = [];
  //define done array of Tasks, initialized empty... this is to be updated in Firebase version
  done: Task [] = [];
  //define blocked array of Tasks, initialized empty... this is to be updated in Firebase version
  blocked: Task [] = [];

  //define editTask method, accepts parameters of list (set to any of the values of the swimlanes)
  editTask(list: 'done' | 'blocked' | 'todo' | 'inProgress', task: Task): void {
    //defines dialogRef method that opens the TaskDialogComponent dialog, sets width and data to the task, enabling delete
    const dialogRef = this.dialog.open(TaskDialogComponent, {
      width: '270px',
      data: {
        task,
        enableDelete: true,
      },
    });
    //chain afterClosed and subscribe methods of the dialogRef 
    //to accept parameter of the result of type TaskDialogResult (undefined)
    dialogRef.afterClosed().subscribe((result: TaskDialogResult|undefined) => {
      //if no result, simply return immediately
      if (!result) {
        return;
      }
      //otherwise define dataList property that is this list property sent to the editTask method
      const dataList = this[list];
      //define taskIndex property that is the index value of the current task in the dataList
      const taskIndex = dataList.indexOf(task);
      //if the delete property is set on the result (set to true), then splice the dataList at the indicated index
      if (result.delete) {
        dataList.splice(taskIndex, 1);
      } else { //set the same index of the dataList equal to the task from the dialog result (existing task, cancel...)
        dataList[taskIndex] = task;
      }
    });
  }

  //define drop method, accepts an event of the type CdkDragDrop<Task[]>, the dragging and dropping of a Task
  drop(event: CdkDragDrop<Task[]>) : void {
    //check if we are dropping in the same list that the task is coming from. If so, return immediately
    if (event.previousContainer === event.container) {
      return;
    }
    if (!event.container.data || !event.previousContainer.data) {
      return;
    }
    //othrwise, call transferArrayItem method and pass the data in the current/previous container, plus the current and previous index of the drag/drop task event
    transferArrayItem(
      event.previousContainer.data,
      event.container.data,
      event.previousIndex,
      event.currentIndex
    );
  }

  //declare constructor in which to inject MatDialog class (private type dialog)
  //in the firebase version, they say to add another type variable that the constructor accepts...
  constructor(private dialog: MatDialog) {}

  //newTask method
  newTask(): void {
    //variable to store new open TaskDialogComponent dialog, define its wdith and data (empty task to start)
    //TaskDialogComponent will get a reference to the data
    const dialogRef = this.dialog.open(TaskDialogComponent, {
      width: '270px',
      data: {
        task: {},
      },
    });
    //after the dialog is closed, subscribe to the close event and add the task from the result object to the todo array
    //subscribe method tasks result as parameter which is a TaskDialogResult component, initialized undefined
    //if not result, simply return. Otherwise, push the new task (result prop) to the todo array
    dialogRef
      .afterClosed()
      .subscribe((result: TaskDialogResult|undefined) => {
        if (!result) {
          return;
        }
        this.todo.push(result.task);
      });
  }
}
