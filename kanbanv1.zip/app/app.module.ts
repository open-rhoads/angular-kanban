import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
//using the ng add @angular/material command in CLI, material has been added to project
//Routing components
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
// BrowserAnimationsModule was imported using the ng add @angular/material command in CLI
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
//add imports for MatToolbarModule & MatIconModule to use in App template
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatIconModule } from '@angular/material/icon';
import { TaskComponent } from './task/task.component';
//import MatCardModule to display tasks
import { MatCardModule } from '@angular/material/card';
//import DragDropModule from cdk for task swimlane behavior
import { DragDropModule } from '@angular/cdk/drag-drop';
//import MatButtonModule from materal to use for buttons
import { MatButtonModule } from '@angular/material/button';
//import MatDialogModule to use for adding tasks
import { MatDialogModule } from '@angular/material/dialog';
import { TaskDialogComponent } from './task-dialog/task-dialog.component';
//import MatInputModule from material
import { MatInputModule } from '@angular/material/input';
//import FormsModule from angular forms (for ngModel)
import { FormsModule } from '@angular/forms';

@NgModule({
  declarations: [
    AppComponent,
    TaskComponent,
    TaskDialogComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    MatToolbarModule,
    MatIconModule,
    MatCardModule,
    DragDropModule,
    MatButtonModule,
    MatDialogModule,
    MatInputModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
