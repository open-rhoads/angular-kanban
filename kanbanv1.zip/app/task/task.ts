//this class will define the interface of the tasks in the kanban board
//each task will have an optional id, title, and description string values

export interface Task {
    id?: string;
    title: string;
    description: string;
}