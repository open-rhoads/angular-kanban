//task component will accept as an input the task object and allow it to emit the edit outputs
//import these additional objects from angular core
import { Component, Input, Output, EventEmitter } from '@angular/core';
//import task class type defined in task.ts
import { Task } from './task';

@Component({
  selector: 'app-task',
  templateUrl: './task.component.html',
  styleUrls: ['./task.component.css']
})
export class TaskComponent {
  //add input and output to the task component
  //task input of type task, assigned initial null value
  @Input() task: Task | null = null;
  //edit output is a new EventEmitter object of the Task.
  @Output() edit = new EventEmitter<Task>();
}
